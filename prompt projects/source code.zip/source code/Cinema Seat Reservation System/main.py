"""
Cinema Seat Reservation System
================================
A CLI-based seat booking simulator for a small cinema hall.
Demonstrates: 2D lists, modular functions, input validation, state management.
"""

# ──────────────────────────────────────────────
# CONSTANTS
# ──────────────────────────────────────────────
ROWS = 5
COLS = 6
AVAILABLE = "O"
RESERVED  = "X"

ROW_LABELS = ["A", "B", "C", "D", "E"]   # human-friendly row names


# ──────────────────────────────────────────────
# SEAT INITIALIZER
# ──────────────────────────────────────────────
def create_hall() -> list[list[str]]:
    """
    Create and return a fresh 2D list representing the cinema hall.
    Every seat starts as AVAILABLE ("O").
    """
    return [[AVAILABLE] * COLS for _ in range(ROWS)]


# ──────────────────────────────────────────────
# DISPLAY
# ──────────────────────────────────────────────
def show_seats(hall: list[list[str]]) -> None:
    """
    Print the seating chart with row labels and column numbers.

    Example output:
        Col →   1   2   3   4   5   6
        A       O   O   O   O   O   O
        B       O   O   X   O   O   O
    """
    print()
    print("  ┌─────────────────────────────────────┐")
    print("  │           SEATING CHART             │")
    print("  └─────────────────────────────────────┘")

    # Column header
    header = "       " + "   ".join(str(c + 1) for c in range(COLS))
    print(f"  Col → {header[7:]}")
    print("        " + "─" * (COLS * 4 - 1))

    for r, row in enumerate(hall):
        seats = "   ".join(row)
        print(f"   {ROW_LABELS[r]}  │  {seats}")

    print()
    available_count = sum(seat == AVAILABLE for row in hall for seat in row)
    reserved_count  = ROWS * COLS - available_count
    print(f"   O = Available ({available_count})    X = Reserved ({reserved_count})")
    print()


# ──────────────────────────────────────────────
# INPUT HELPERS
# ──────────────────────────────────────────────
def get_seat_input() -> tuple[int, int] | None:
    """
    Prompt the user for a seat (row letter + column number).
    Returns (row_index, col_index) on success, or None on invalid input.

    Accepts input formats:
        - Row as letter: A, B, C, D, E  (case-insensitive)
        - Column as number: 1 – 6
    """
    raw_row = input("   Enter row    (A–E): ").strip().upper()
    raw_col = input("   Enter column (1–6): ").strip()

    # Validate row
    if raw_row not in ROW_LABELS:
        print(f"\n   ✗  '{raw_row}' is not a valid row. Choose from A to E.\n")
        return None

    # Validate column
    try:
        col = int(raw_col)
    except ValueError:
        print(f"\n   ✗  '{raw_col}' is not a number. Enter a value between 1 and 6.\n")
        return None

    if not (1 <= col <= COLS):
        print(f"\n   ✗  Column {col} is out of range. Choose between 1 and {COLS}.\n")
        return None

    row_index = ROW_LABELS.index(raw_row)
    col_index = col - 1          # convert 1-based user input to 0-based index
    return row_index, col_index


# ──────────────────────────────────────────────
# CORE FEATURES
# ──────────────────────────────────────────────
def reserve_seat(hall: list[list[str]]) -> None:
    """
    Ask the user to pick a seat and mark it as RESERVED.
    Rejects the request if the seat is already taken.
    """
    print("\n  ── Reserve a Seat ──────────────────────")
    result = get_seat_input()
    if result is None:
        return

    row_idx, col_idx = result
    seat_label = f"{ROW_LABELS[row_idx]}{col_idx + 1}"

    if hall[row_idx][col_idx] == RESERVED:
        print(f"\n   ✗  Seat {seat_label} is already reserved. Choose another seat.\n")
    else:
        hall[row_idx][col_idx] = RESERVED
        print(f"\n   ✓  Seat {seat_label} has been successfully reserved!\n")


def cancel_seat(hall: list[list[str]]) -> None:
    """
    Ask the user to pick a seat and mark it as AVAILABLE again.
    Rejects the request if the seat was not reserved in the first place.
    """
    print("\n  ── Cancel a Reservation ────────────────")
    result = get_seat_input()
    if result is None:
        return

    row_idx, col_idx = result
    seat_label = f"{ROW_LABELS[row_idx]}{col_idx + 1}"

    if hall[row_idx][col_idx] == AVAILABLE:
        print(f"\n   ✗  Seat {seat_label} is not reserved. Nothing to cancel.\n")
    else:
        hall[row_idx][col_idx] = AVAILABLE
        print(f"\n   ✓  Reservation for seat {seat_label} has been cancelled.\n")


# ──────────────────────────────────────────────
# MENU
# ──────────────────────────────────────────────
def print_menu() -> None:
    """Render the main navigation menu."""
    print("  ╔═══════════════════════════════════════╗")
    print("  ║      Cinema Reservation System        ║")
    print("  ╚═══════════════════════════════════════╝")
    print("   1.  Show Seats")
    print("   2.  Reserve a Seat")
    print("   3.  Cancel Reservation")
    print("   4.  Exit")
    print()


def main_menu() -> None:
    """
    Application entry point.

    Owns the cinema hall state (the 2D list) and runs the event loop,
    routing each menu choice to the appropriate function.
    """
    hall = create_hall()

    print()
    print("  Welcome to CinePy – your seat, your choice.")
    print()

    while True:
        print_menu()

        choice = input("  Choose an option (1–4): ").strip()

        if choice == "1":
            show_seats(hall)

        elif choice == "2":
            reserve_seat(hall)

        elif choice == "3":
            cancel_seat(hall)

        elif choice == "4":
            print()
            print("  Thank you for using CinePy. Enjoy the show!")
            print()
            break

        else:
            print(f"\n   ✗  '{choice}' is not a valid option. Please enter 1, 2, 3, or 4.\n")


# ──────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────
if __name__ == "__main__":
    main_menu()