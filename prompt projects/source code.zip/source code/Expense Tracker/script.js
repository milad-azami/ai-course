(() => {
  const form = document.getElementById("transaction-form");
  const titleInput = document.getElementById("title");
  const amountInput = document.getElementById("amount");
  const typeInputs = document.getElementsByName("type");

  const balanceEl = document.getElementById("balance");
  const incomeEl = document.getElementById("income");
  const expenseEl = document.getElementById("expense");
  const listEl = document.getElementById("transaction-list");

  const titleError = document.getElementById("title-error");
  const amountError = document.getElementById("amount-error");
  const typeError = document.getElementById("type-error");

  const STORAGE_KEY = "transactions";

  let transactions = loadTransactions();

  // Load from localStorage
  function loadTransactions() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  }

  // Save to localStorage
  function saveTransactions() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  }

  // Validation
  function validateForm(title, amount, type) {
    let isValid = true;

    titleError.textContent = "";
    amountError.textContent = "";
    typeError.textContent = "";

    if (!title.trim()) {
      titleError.textContent = "Title is required";
      isValid = false;
    }

    if (!amount || amount <= 0) {
      amountError.textContent = "Enter a valid positive amount";
      isValid = false;
    }

    if (!type) {
      typeError.textContent = "Select a transaction type";
      isValid = false;
    }

    return isValid;
  }

  function getSelectedType() {
    for (let input of typeInputs) {
      if (input.checked) return input.value;
    }
    return null;
  }

  // Add transaction
  function addTransaction(e) {
    e.preventDefault();

    const title = titleInput.value;
    const amount = parseFloat(amountInput.value);
    const type = getSelectedType();

    if (!validateForm(title, amount, type)) return;

    const transaction = {
      id: Date.now(),
      title,
      amount,
      type,
    };

    transactions.push(transaction);
    saveTransactions();
    updateUI();
    form.reset();
  }

  // Delete transaction
  function deleteTransaction(id) {
    transactions = transactions.filter((t) => t.id !== id);
    saveTransactions();
    updateUI();
  }

  // Calculate totals
  function calculateTotals() {
    let income = 0;
    let expense = 0;

    transactions.forEach((t) => {
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    });

    const balance = income - expense;

    return { income, expense, balance };
  }

  // Render transactions
  function renderTransactions() {
    listEl.innerHTML = "";

    transactions.forEach((t) => {
      const li = document.createElement("li");
      li.classList.add("transaction", t.type);

      li.innerHTML = `
        <span>${t.title} - $${t.amount.toFixed(2)}</span>
        <button class="delete-btn" onclick="window.deleteTransaction(${t.id})">✖</button>
      `;

      listEl.appendChild(li);
    });
  }

  // Update UI
  function updateUI() {
    const { income, expense, balance } = calculateTotals();

    balanceEl.textContent = `$${balance.toFixed(2)}`;
    incomeEl.textContent = `$${income.toFixed(2)}`;
    expenseEl.textContent = `$${expense.toFixed(2)}`;

    renderTransactions();
  }

  // Expose delete function safely
  window.deleteTransaction = deleteTransaction;

  // Events
  form.addEventListener("submit", addTransaction);

  // Initial render
  updateUI();
})();
