/* ============================================================
   app.js (Section 1)
   Gym Management System
   Core Architecture + State + Storage + Utilities
============================================================ */

/* ============================================================
   STORAGE LAYER
============================================================ */

const StorageService = (() => {
  const KEYS = {
    MEMBERS: "gym_members",
    PLANS: "gym_plans",
    ATTENDANCE: "gym_attendance",
    PAYMENTS: "gym_payments",
    ACTIVITIES: "gym_activities",
  };

  function save(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
  }

  function load(key, fallback = []) {
    const data = localStorage.getItem(key);

    if (!data) return fallback;

    try {
      return JSON.parse(data);
    } catch {
      return fallback;
    }
  }

  return {
    KEYS,
    save,
    load,
  };
})();

/* ============================================================
   STATE MANAGEMENT
============================================================ */

const AppState = {
  members: [],
  plans: [],
  attendance: [],
  payments: [],
  activities: [],

  currentPage: "dashboard",

  editingMember: null,
  editingPlan: null,

  deleteCallback: null,
};

/* ============================================================
   ID GENERATOR
============================================================ */

function generateId(prefix = "") {
  return (
    prefix +
    Date.now().toString(36) +
    Math.random().toString(36).substring(2, 8)
  );
}

/* ============================================================
   DATE UTILITIES
============================================================ */

function today() {
  return new Date().toISOString().split("T")[0];
}

function currentTime() {
  return new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDate(date) {
  if (!date) return "-";

  return new Date(date).toLocaleDateString();
}

function isMembershipExpired(endDate) {
  if (!endDate) return true;

  return new Date(endDate) < new Date(today());
}

function getMonthRevenue() {
  const now = new Date();

  return AppState.payments
    .filter((payment) => {
      const paymentDate = new Date(payment.paymentDate);

      return (
        paymentDate.getMonth() === now.getMonth() &&
        paymentDate.getFullYear() === now.getFullYear()
      );
    })
    .reduce((sum, payment) => sum + Number(payment.amount), 0);
}

/* ============================================================
   ACTIVITY LOG
============================================================ */

function addActivity(message) {
  AppState.activities.unshift({
    id: generateId("act_"),
    message,
    time: new Date().toLocaleString(),
  });

  if (AppState.activities.length > 20) {
    AppState.activities.length = 20;
  }

  StorageService.save(StorageService.KEYS.ACTIVITIES, AppState.activities);
}

/* ============================================================
   VALIDATION
============================================================ */

const Validator = {
  email(email) {
    if (!email) return true;

    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  phone(phone) {
    return /^[0-9+\-\s]{6,20}$/.test(phone);
  },

  amount(value) {
    return Number(value) > 0;
  },

  required(value) {
    return String(value).trim() !== "";
  },

  membershipDates(start, end) {
    return new Date(start) <= new Date(end);
  },
};

/* ============================================================
   DOM HELPERS
============================================================ */

const $ = (selector) => document.querySelector(selector);

const $$ = (selector) => Array.from(document.querySelectorAll(selector));

/* ============================================================
   TOAST SYSTEM
============================================================ */

function showToast(message, type = "success") {
  const container = $("#toastContainer");

  const toast = document.createElement("div");

  toast.className = `toast ${type}`;

  toast.textContent = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

/* ============================================================
   MODAL HELPERS
============================================================ */

function openModal(id) {
  document.getElementById(id).classList.remove("hidden");
}

function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}

function closeAllModals() {
  $$(".modal").forEach((modal) => {
    modal.classList.add("hidden");
  });
}

/* ============================================================
   LOCAL STORAGE LOAD
============================================================ */

function loadState() {
  AppState.members = StorageService.load(StorageService.KEYS.MEMBERS);

  AppState.plans = StorageService.load(StorageService.KEYS.PLANS);

  AppState.attendance = StorageService.load(StorageService.KEYS.ATTENDANCE);

  AppState.payments = StorageService.load(StorageService.KEYS.PAYMENTS);

  AppState.activities = StorageService.load(StorageService.KEYS.ACTIVITIES);
}

/* ============================================================
   SAVE HELPERS
============================================================ */

function saveMembers() {
  StorageService.save(StorageService.KEYS.MEMBERS, AppState.members);
}

function savePlans() {
  StorageService.save(StorageService.KEYS.PLANS, AppState.plans);
}

function saveAttendance() {
  StorageService.save(StorageService.KEYS.ATTENDANCE, AppState.attendance);
}

function savePayments() {
  StorageService.save(StorageService.KEYS.PAYMENTS, AppState.payments);
}

/* ============================================================
   DEFAULT MEMBERSHIP PLANS
============================================================ */

function seedPlans() {
  if (AppState.plans.length > 0) return;

  AppState.plans = [
    {
      id: generateId("plan_"),
      name: "Monthly",
      durationMonths: 1,
      price: 50,
    },
    {
      id: generateId("plan_"),
      name: "Quarterly",
      durationMonths: 3,
      price: 130,
    },
    {
      id: generateId("plan_"),
      name: "Semi Annual",
      durationMonths: 6,
      price: 240,
    },
    {
      id: generateId("plan_"),
      name: "Annual",
      durationMonths: 12,
      price: 450,
    },
  ];

  savePlans();
}

/* ============================================================
   MEMBER HELPERS
============================================================ */

function getMemberById(id) {
  return AppState.members.find((member) => member.id === id);
}

function getPlanById(id) {
  return AppState.plans.find((plan) => plan.id === id);
}

function getMemberName(id) {
  const member = getMemberById(id);

  return member ? member.fullName : "-";
}

function getPlanName(id) {
  const plan = getPlanById(id);

  return plan ? plan.name : "-";
}

/* ============================================================
   MEMBERSHIP STATUS
============================================================ */

function memberStatus(member) {
  return isMembershipExpired(member.membershipEndDate) ? "expired" : "active";
}

/* ============================================================
   NAVIGATION
============================================================ */

function navigate(page) {
  AppState.currentPage = page;

  $$(".page").forEach((section) => {
    section.classList.remove("active-page");
  });

  $$(".nav-item").forEach((button) => {
    button.classList.remove("active");
  });

  $("#" + page + "Page").classList.add("active-page");

  document.querySelector(`[data-page="${page}"]`).classList.add("active");

  $("#pageTitle").textContent = page.charAt(0).toUpperCase() + page.slice(1);

  renderDashboard();
  renderReports();
}

/* ============================================================
   DASHBOARD RENDER
============================================================ */

function renderDashboard() {
  $("#totalMembers").textContent = AppState.members.length;

  const active = AppState.members.filter(
    (member) => memberStatus(member) === "active",
  ).length;

  const expired = AppState.members.filter(
    (member) => memberStatus(member) === "expired",
  ).length;

  const todayCount = AppState.attendance.filter(
    (item) => item.date === today(),
  ).length;

  $("#activeMembers").textContent = active;

  $("#expiredMembers").textContent = expired;

  $("#todayAttendance").textContent = todayCount;

  $("#monthlyRevenue").textContent = "$" + getMonthRevenue();

  renderActivity();
}

/* ============================================================
   RECENT ACTIVITY
============================================================ */

function renderActivity() {
  const container = $("#recentActivity");

  if (!AppState.activities.length) {
    container.innerHTML = `
            <div class="empty-state">
                No recent activity.
            </div>
        `;
    return;
  }

  container.innerHTML = AppState.activities
    .slice(0, 10)
    .map(
      (activity) => `
                <div class="activity-item">
                    <div>
                        ${activity.message}
                    </div>
                    <div class="activity-time">
                        ${activity.time}
                    </div>
                </div>
            `,
    )
    .join("");
}

/* ============================================================
   REPORTS
============================================================ */

function renderReports() {
  const active = AppState.members.filter(
    (m) => memberStatus(m) === "active",
  ).length;

  const expired = AppState.members.filter(
    (m) => memberStatus(m) === "expired",
  ).length;

  $("#reportActive").textContent = active;

  $("#reportExpired").textContent = expired;

  $("#reportRevenue").textContent = "$" + getMonthRevenue();

  $("#reportAttendance").textContent = AppState.attendance.length;

  $("#reportTableBody").innerHTML = `
        <tr>
            <td>Total Members</td>
            <td>${AppState.members.length}</td>
        </tr>

        <tr>
            <td>Active Members</td>
            <td>${active}</td>
        </tr>

        <tr>
            <td>Expired Members</td>
            <td>${expired}</td>
        </tr>

        <tr>
            <td>Total Payments</td>
            <td>${AppState.payments.length}</td>
        </tr>

        <tr>
            <td>Monthly Revenue</td>
            <td>$${getMonthRevenue()}</td>
        </tr>

        <tr>
            <td>Attendance Records</td>
            <td>${AppState.attendance.length}</td>
        </tr>
    `;
}

/* ============================================================
   CURRENT DATE
============================================================ */

function renderCurrentDate() {
  $("#currentDate").textContent = new Date().toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/* ============================================================
   DELETE CONFIRMATION
============================================================ */

function confirmDelete(message, callback) {
  $("#confirmText").textContent = message;

  AppState.deleteCallback = callback;

  openModal("confirmModal");
}

$("#confirmDelete").addEventListener("click", () => {
  if (AppState.deleteCallback) {
    AppState.deleteCallback();
  }

  closeModal("confirmModal");

  AppState.deleteCallback = null;
});

$("#cancelConfirm").addEventListener("click", () => {
  closeModal("confirmModal");

  AppState.deleteCallback = null;
});

/* ============================================================
   INITIALIZATION
============================================================ */

function initializeApp() {
  loadState();

  seedPlans();

  renderCurrentDate();

  renderDashboard();

  renderReports();
}

document.addEventListener("DOMContentLoaded", initializeApp);

/* ============================================================
   app.js (Section 2)
   Member Management + Membership Plans + Payments
============================================================ */

/* ============================================================
   MEMBER RENDERING
============================================================ */

function renderMembers() {
  const tbody = $("#memberTableBody");
  const empty = $("#memberEmptyState");

  let members = [...AppState.members];

  const search = $("#memberSearch").value.toLowerCase().trim();

  const filter = $("#memberFilter").value;
  const sort = $("#memberSort").value;

  if (search) {
    members = members.filter(
      (member) =>
        member.fullName.toLowerCase().includes(search) ||
        member.phone.toLowerCase().includes(search),
    );
  }

  if (filter !== "all") {
    members = members.filter((member) => memberStatus(member) === filter);
  }

  if (sort === "name") {
    members.sort((a, b) => a.fullName.localeCompare(b.fullName));
  }

  if (sort === "date") {
    members.sort((a, b) => new Date(b.joinDate) - new Date(a.joinDate));
  }

  if (!members.length) {
    tbody.innerHTML = "";
    empty.style.display = "block";
    return;
  }

  empty.style.display = "none";

  tbody.innerHTML = members
    .map((member) => {
      const status = memberStatus(member);

      return `
            <tr>
                <td>${member.fullName}</td>
                <td>${member.phone}</td>
                <td>${getPlanName(member.membershipPlanId)}</td>
                <td>
                    <span class="badge ${status}">
                        ${status}
                    </span>
                </td>
                <td>
                    ${formatDate(member.membershipEndDate)}
                </td>

                <td>
                    <div class="action-buttons">

                        <button
                            class="icon-btn view-btn"
                            onclick="showMemberProfile('${member.id}')">
                            👁
                        </button>

                        <button
                            class="icon-btn edit-btn"
                            onclick="editMember('${member.id}')">
                            ✏
                        </button>

                        <button
                            class="icon-btn delete-btn"
                            onclick="deleteMember('${member.id}')">
                            🗑
                        </button>

                    </div>
                </td>
            </tr>
        `;
    })
    .join("");
}

/* ============================================================
   MEMBER PROFILE
============================================================ */

function showMemberProfile(id) {
  const member = getMemberById(id);

  if (!member) return;

  $("#profileBody").innerHTML = `
        <div class="profile-section">

            <div class="profile-row">
                <span class="profile-label">Name</span>
                <span>${member.fullName}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Phone</span>
                <span>${member.phone}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Email</span>
                <span>${member.email || "-"}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Gender</span>
                <span>${member.gender}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Age</span>
                <span>${member.age}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Plan</span>
                <span>${getPlanName(member.membershipPlanId)}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Join Date</span>
                <span>${formatDate(member.joinDate)}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Membership End</span>
                <span>${formatDate(member.membershipEndDate)}</span>
            </div>

            <div class="profile-row">
                <span class="profile-label">Notes</span>
                <span>${member.notes || "-"}</span>
            </div>

        </div>
    `;

  openModal("profileModal");
}

/* ============================================================
   MEMBER FORM
============================================================ */

function populatePlanDropdowns() {
  const options = AppState.plans
    .map(
      (plan) => `
            <option value="${plan.id}">
                ${plan.name} ($${plan.price})
            </option>
        `,
    )
    .join("");

  $("#memberPlan").innerHTML = options;

  $("#attendanceMemberSelect").innerHTML =
    `<option value="">Select Member</option>` +
    AppState.members
      .map(
        (member) => `
                <option value="${member.id}">
                    ${member.fullName}
                </option>
            `,
      )
      .join("");

  $("#paymentMember").innerHTML = AppState.members
    .map(
      (member) => `
                <option value="${member.id}">
                    ${member.fullName}
                </option>
            `,
    )
    .join("");
}

function resetMemberForm() {
  $("#memberForm").reset();

  $("#memberId").value = "";

  AppState.editingMember = null;
}

$("#addMemberBtn").addEventListener("click", () => {
  resetMemberForm();

  $("#memberModalTitle").textContent = "Add Member";

  $("#memberJoinDate").value = today();

  $("#membershipStart").value = today();

  openModal("memberModal");
});

function editMember(id) {
  const member = getMemberById(id);

  if (!member) return;

  AppState.editingMember = id;

  $("#memberModalTitle").textContent = "Edit Member";

  $("#memberId").value = member.id;
  $("#memberName").value = member.fullName;
  $("#memberPhone").value = member.phone;
  $("#memberEmail").value = member.email;
  $("#memberGender").value = member.gender;
  $("#memberAge").value = member.age;
  $("#memberPlan").value = member.membershipPlanId;
  $("#memberJoinDate").value = member.joinDate;
  $("#membershipStart").value = member.membershipStartDate;
  $("#membershipEnd").value = member.membershipEndDate;
  $("#memberNotes").value = member.notes;

  openModal("memberModal");
}

function deleteMember(id) {
  confirmDelete("Delete this member?", () => {
    AppState.members = AppState.members.filter((member) => member.id !== id);

    saveMembers();

    addActivity("Member deleted.");

    renderMembers();
    renderDashboard();
    populatePlanDropdowns();

    showToast("Member deleted.", "warning");
  });
}

$("#memberForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const fullName = $("#memberName").value.trim();

  const phone = $("#memberPhone").value.trim();

  const email = $("#memberEmail").value.trim();

  const start = $("#membershipStart").value;

  const end = $("#membershipEnd").value;

  if (!Validator.required(fullName)) {
    return showToast("Name required", "error");
  }

  if (!Validator.phone(phone)) {
    return showToast("Invalid phone number", "error");
  }

  if (!Validator.email(email)) {
    return showToast("Invalid email", "error");
  }

  if (!Validator.membershipDates(start, end)) {
    return showToast("Invalid membership dates", "error");
  }

  const member = {
    id: $("#memberId").value || generateId("mem_"),

    fullName,

    phone,

    email,

    gender: $("#memberGender").value,

    age: $("#memberAge").value,

    membershipPlanId: $("#memberPlan").value,

    joinDate: $("#memberJoinDate").value,

    membershipStartDate: start,

    membershipEndDate: end,

    notes: $("#memberNotes").value,
  };

  if (AppState.editingMember) {
    const index = AppState.members.findIndex((m) => m.id === member.id);

    AppState.members[index] = member;

    addActivity(`Member updated: ${member.fullName}`);
  } else {
    AppState.members.push(member);

    addActivity(`New member added: ${member.fullName}`);
  }

  saveMembers();

  renderMembers();
  renderDashboard();
  renderReports();

  populatePlanDropdowns();

  closeModal("memberModal");

  showToast("Member saved successfully.");
});

/* ============================================================
   MEMBERSHIP PLANS
============================================================ */

function renderPlans() {
  const container = $("#plansContainer");

  if (!AppState.plans.length) {
    container.innerHTML = `
            <div class="empty-state">
                No plans available.
            </div>
        `;
    return;
  }

  container.innerHTML = AppState.plans
    .map(
      (plan) => `
                <div class="plan-card">

                    <h3>
                        ${plan.name}
                    </h3>

                    <div class="plan-price">
                        $${plan.price}
                    </div>

                    <div class="plan-duration">
                        ${plan.durationMonths}
                        month(s)
                    </div>

                    <div class="action-buttons">

                        <button
                            class="icon-btn edit-btn"
                            onclick="editPlan('${plan.id}')">
                            Edit
                        </button>

                        <button
                            class="icon-btn delete-btn"
                            onclick="deletePlan('${plan.id}')">
                            Delete
                        </button>

                    </div>

                </div>
            `,
    )
    .join("");
}

$("#addPlanBtn").addEventListener("click", () => {
  AppState.editingPlan = null;

  $("#planForm").reset();

  $("#planId").value = "";

  $("#planModalTitle").textContent = "Add Membership Plan";

  openModal("planModal");
});

function editPlan(id) {
  const plan = getPlanById(id);

  if (!plan) return;

  AppState.editingPlan = id;

  $("#planId").value = plan.id;
  $("#planName").value = plan.name;
  $("#planDuration").value = plan.durationMonths;
  $("#planPrice").value = plan.price;

  $("#planModalTitle").textContent = "Edit Membership Plan";

  openModal("planModal");
}

function deletePlan(id) {
  confirmDelete("Delete this plan?", () => {
    AppState.plans = AppState.plans.filter((p) => p.id !== id);

    savePlans();

    renderPlans();

    populatePlanDropdowns();

    showToast("Plan deleted.", "warning");
  });
}

$("#planForm").addEventListener("submit", (e) => {
  e.preventDefault();

  const plan = {
    id: $("#planId").value || generateId("plan_"),

    name: $("#planName").value,

    durationMonths: Number($("#planDuration").value),

    price: Number($("#planPrice").value),
  };

  if (AppState.editingPlan) {
    const index = AppState.plans.findIndex((p) => p.id === plan.id);

    AppState.plans[index] = plan;
  } else {
    AppState.plans.push(plan);
  }

  savePlans();

  renderPlans();

  populatePlanDropdowns();

  closeModal("planModal");

  showToast("Plan saved successfully.");
});

/* ============================================================
   PAYMENTS
============================================================ */

function renderPayments() {
  const search = $("#paymentSearch").value.toLowerCase();

  const payments = AppState.payments.filter((payment) => {
    return getMemberName(payment.memberId).toLowerCase().includes(search);
  });

  $("#paymentTableBody").innerHTML = payments
    .map(
      (payment) => `
                <tr>

                    <td>
                        ${getMemberName(payment.memberId)}
                    </td>

                    <td>
                        $${payment.amount}
                    </td>

                    <td>
                        ${formatDate(payment.paymentDate)}
                    </td>

                    <td>
                        ${payment.paymentMethod}
                    </td>

                    <td>
                        ${payment.notes || "-"}
                    </td>

                </tr>
            `,
    )
    .join("");
}

$("#addPaymentBtn").addEventListener("click", () => {
  $("#paymentForm").reset();

  $("#paymentDate").value = today();

  openModal("paymentModal");
});

$("#paymentForm").addEventListener("submit", (e) => {
  e.preventDefault();

  const amount = Number($("#paymentAmount").value);

  if (!Validator.amount(amount)) {
    return showToast("Invalid amount", "error");
  }

  const payment = {
    id: generateId("pay_"),

    memberId: $("#paymentMember").value,

    amount,

    paymentDate: $("#paymentDate").value,

    paymentMethod: $("#paymentMethod").value,

    notes: $("#paymentNotes").value,
  };

  AppState.payments.push(payment);

  savePayments();

  addActivity(`Payment recorded: $${amount}`);

  renderPayments();
  renderDashboard();
  renderReports();

  closeModal("paymentModal");

  showToast("Payment recorded.");
});

$("#paymentSearch").addEventListener("input", renderPayments);

/* ============================================================
   MEMBER FILTERS
============================================================ */

$("#memberSearch").addEventListener("input", renderMembers);

$("#memberFilter").addEventListener("change", renderMembers);

$("#memberSort").addEventListener("change", renderMembers);
/* ============================================================
   app.js (Section 3)
   Attendance + Navigation + Events + App Startup
============================================================ */

/* ============================================================
   ATTENDANCE SYSTEM
============================================================ */

function hasCheckedInToday(memberId) {
  return AppState.attendance.some(
    (record) => record.memberId === memberId && record.date === today(),
  );
}

function getTodayAttendance(memberId) {
  return AppState.attendance.find(
    (record) => record.memberId === memberId && record.date === today(),
  );
}

$("#checkInBtn").addEventListener("click", () => {
  const memberId = $("#attendanceMemberSelect").value;

  if (!memberId) {
    return showToast("Select a member.", "error");
  }

  if (hasCheckedInToday(memberId)) {
    return showToast("Member already checked in.", "warning");
  }

  const attendance = {
    id: generateId("att_"),
    memberId,
    date: today(),
    checkInTime: currentTime(),
    checkOutTime: "",
  };

  AppState.attendance.push(attendance);

  saveAttendance();

  addActivity(`${getMemberName(memberId)} checked in.`);

  renderAttendance();

  renderDashboard();

  renderReports();

  showToast("Check in successful.");
});

$("#checkOutBtn").addEventListener("click", () => {
  const memberId = $("#attendanceMemberSelect").value;

  if (!memberId) {
    return showToast("Select a member.", "error");
  }

  const attendance = getTodayAttendance(memberId);

  if (!attendance) {
    return showToast("Member has not checked in.", "error");
  }

  if (attendance.checkOutTime) {
    return showToast("Already checked out.", "warning");
  }

  attendance.checkOutTime = currentTime();

  saveAttendance();

  addActivity(`${getMemberName(memberId)} checked out.`);

  renderAttendance();

  showToast("Check out successful.");
});

/* ============================================================
   ATTENDANCE RENDERING
============================================================ */

function renderAttendance() {
  const todayBody = $("#todayAttendanceTable");

  const historyBody = $("#attendanceHistoryTable");

  const todayRecords = AppState.attendance.filter(
    (record) => record.date === today(),
  );

  if (!todayRecords.length) {
    todayBody.innerHTML = `
            <tr>
                <td colspan="4">
                    No attendance today.
                </td>
            </tr>
        `;
  } else {
    todayBody.innerHTML = todayRecords
      .map(
        (record) => `
                    <tr>

                        <td>
                            ${getMemberName(record.memberId)}
                        </td>

                        <td>
                            ${record.date}
                        </td>

                        <td>
                            ${record.checkInTime}
                        </td>

                        <td>
                            ${record.checkOutTime || "-"}
                        </td>

                    </tr>
                `,
      )
      .join("");
  }

  if (!AppState.attendance.length) {
    historyBody.innerHTML = `
            <tr>
                <td colspan="4">
                    No attendance records.
                </td>
            </tr>
        `;
  } else {
    historyBody.innerHTML = [...AppState.attendance]
      .reverse()
      .map(
        (record) => `
                    <tr>

                        <td>
                            ${getMemberName(record.memberId)}
                        </td>

                        <td>
                            ${record.date}
                        </td>

                        <td>
                            ${record.checkInTime}
                        </td>

                        <td>
                            ${record.checkOutTime || "-"}
                        </td>

                    </tr>
                `,
      )
      .join("");
  }
}

/* ============================================================
   SIDEBAR NAVIGATION
============================================================ */

$$(".nav-item").forEach((button) => {
  button.addEventListener("click", () => {
    const page = button.dataset.page;

    navigate(page);

    if (window.innerWidth < 992) {
      $("#sidebar").classList.remove("show");
    }
  });
});

/* ============================================================
   MOBILE SIDEBAR
============================================================ */

$("#menuToggle").addEventListener("click", () => {
  $("#sidebar").classList.toggle("show");
});

/* ============================================================
   CLOSE MODALS
============================================================ */

$$(".close-modal").forEach((button) => {
  button.addEventListener("click", () => {
    const id = button.dataset.close;

    closeModal(id);
  });
});

$$(".modal").forEach((modal) => {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.classList.add("hidden");
    }
  });
});

/* ============================================================
   ESCAPE KEY
============================================================ */

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeAllModals();
  }
});

/* ============================================================
   AUTO MEMBERSHIP END DATE
============================================================ */

$("#memberPlan").addEventListener("change", () => {
  const planId = $("#memberPlan").value;

  const startDate = $("#membershipStart").value;

  if (!planId || !startDate) {
    return;
  }

  const plan = getPlanById(planId);

  if (!plan) return;

  const end = new Date(startDate);

  end.setMonth(end.getMonth() + Number(plan.durationMonths));

  $("#membershipEnd").value = end.toISOString().split("T")[0];
});

$("#membershipStart").addEventListener("change", () => {
  $("#memberPlan").dispatchEvent(new Event("change"));
});

/* ============================================================
   PAGE REFRESH HELPERS
============================================================ */

function refreshUI() {
  renderDashboard();

  renderReports();

  renderMembers();

  renderPlans();

  renderAttendance();

  renderPayments();

  populatePlanDropdowns();
}

/* ============================================================
   WINDOW HELPERS
============================================================ */

window.editMember = editMember;
window.deleteMember = deleteMember;
window.showMemberProfile = showMemberProfile;

window.editPlan = editPlan;
window.deletePlan = deletePlan;

/* ============================================================
   OVERRIDE INITIALIZER
============================================================ */

function initializeApplication() {
  loadState();

  seedPlans();

  renderCurrentDate();

  populatePlanDropdowns();

  refreshUI();

  navigate("dashboard");

  addActivity("Gym Management System loaded.");

  showToast("Application ready.");
}

/* ============================================================
   AUTO SAVE TIMER
============================================================ */

setInterval(() => {
  saveMembers();
  savePlans();
  saveAttendance();
  savePayments();
}, 10000);

/* ============================================================
   BEFORE UNLOAD SAVE
============================================================ */

window.addEventListener("beforeunload", () => {
  saveMembers();
  savePlans();
  saveAttendance();
  savePayments();
});

/* ============================================================
   START APPLICATION
============================================================ */

document.removeEventListener("DOMContentLoaded", initializeApp);

document.addEventListener("DOMContentLoaded", initializeApplication);

/* ============================================================
   INITIAL EMPTY STATES
============================================================ */

if ($("#memberTableBody")) {
  $("#memberTableBody").innerHTML = `
        <tr>
            <td colspan="6">
                No members available.
            </td>
        </tr>
    `;
}

if ($("#paymentTableBody")) {
  $("#paymentTableBody").innerHTML = `
        <tr>
            <td colspan="5">
                No payments found.
            </td>
        </tr>
    `;
}

if ($("#todayAttendanceTable")) {
  $("#todayAttendanceTable").innerHTML = `
        <tr>
            <td colspan="4">
                No attendance today.
            </td>
        </tr>
    `;
}

if ($("#attendanceHistoryTable")) {
  $("#attendanceHistoryTable").innerHTML = `
        <tr>
            <td colspan="4">
                No attendance records.
            </td>
        </tr>
    `;
}

/* ============================================================
   DEMO DATA (OPTIONAL)
   Uncomment if needed.

AppState.members.push({
    id: generateId("mem_"),
    fullName: "John Smith",
    phone: "1234567890",
    email: "john@example.com",
    gender: "Male",
    age: 30,
    membershipPlanId: AppState.plans[0]?.id,
    joinDate: today(),
    membershipStartDate: today(),
    membershipEndDate: today(),
    notes: "Regular member"
});

saveMembers();
refreshUI();

============================================================ */
