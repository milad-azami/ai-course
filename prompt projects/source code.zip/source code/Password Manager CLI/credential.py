"""
credential.py

Represents a credential stored in the password vault.
"""

from __future__ import annotations

from datetime import datetime


class Credential:
    """
    Represents a single credential record.

    Structure:
    {
        id,
        website,
        username,
        password,
        notes,
        created_at,
        updated_at
    }
    """

    def __init__(
        self,
        credential_id: str,
        website: str,
        username: str,
        password: str,
        notes: str = "",
        created_at: str | None = None,
        updated_at: str | None = None,
    ) -> None:
        self.id = credential_id
        self.website = website.strip()
        self.username = username
        self.password = password
        self.notes = notes

        timestamp = datetime.utcnow().isoformat()

        self.created_at = created_at or timestamp
        self.updated_at = updated_at or timestamp

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(self) -> None:
        """
        Validate credential fields.

        Raises:
            ValueError: If any required field is invalid.
        """
        if not self.id.strip():
            raise ValueError("Credential ID cannot be empty.")

        if not self.website.strip():
            raise ValueError("Website cannot be empty.")

        if not self.username.strip():
            raise ValueError("Username cannot be empty.")

        if not self.password.strip():
            raise ValueError("Password cannot be empty.")

    # ------------------------------------------------------------------
    # Update Methods
    # ------------------------------------------------------------------

    def update(
        self,
        website: str | None = None,
        username: str | None = None,
        password: str | None = None,
        notes: str | None = None,
    ) -> None:
        """
        Update credential fields.

        Args:
            website: New website.
            username: New username.
            password: New password.
            notes: New notes.
        """
        if website is not None and website.strip():
            self.website = website.strip()

        if username is not None:
            self.username = username

        if password is not None:
            self.password = password

        if notes is not None:
            self.notes = notes

        self.touch()

    def touch(self) -> None:
        """
        Update the modification timestamp.
        """
        self.updated_at = datetime.utcnow().isoformat()

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
        Convert credential into a dictionary.

        Returns:
            dict
        """
        return {
            "id": self.id,
            "website": self.website,
            "username": self.username,
            "password": self.password,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Credential":
        """
        Create a Credential object from a dictionary.

        Args:
            data: Dictionary data.

        Returns:
            Credential
        """
        required_fields = {
            "id",
            "website",
            "username",
            "password",
            "notes",
            "created_at",
            "updated_at",
        }

        missing = required_fields - set(data.keys())

        if missing:
            raise ValueError(
                f"Credential data is corrupted. Missing fields: "
                f"{', '.join(sorted(missing))}"
            )

        credential = cls(
            credential_id=str(data["id"]),
            website=str(data["website"]),
            username=str(data["username"]),
            password=str(data["password"]),
            notes=str(data["notes"]),
            created_at=str(data["created_at"]),
            updated_at=str(data["updated_at"]),
        )

        credential.validate()
        return credential

    # ------------------------------------------------------------------
    # Display Helpers
    # ------------------------------------------------------------------

    def to_safe_dict(self) -> dict:
        """
        Return a dictionary that excludes sensitive values.

        Useful for listings and logs.

        Returns:
            dict
        """
        return {
            "id": self.id,
            "website": self.website,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    # ------------------------------------------------------------------
    # Representation Methods
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Credential("
            f"id={self.id!r}, "
            f"website={self.website!r})"
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Credential):
            return False

        return self.id == other.id