"""
encryption_manager.py

Provides secure encryption and decryption services for the
password manager using Fernet symmetric encryption.
"""

from __future__ import annotations

import base64
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken


class EncryptionManager:
    """
    Handles encryption key generation, loading,
    encryption, and decryption operations.
    """

    def __init__(self, storage_dir: Path) -> None:
        self.storage_dir = storage_dir
        self.key_file = self.storage_dir / "key.key"

        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.key = self._load_or_create_key()
        self.fernet = Fernet(self.key)

    # ------------------------------------------------------------------
    # Key Management
    # ------------------------------------------------------------------

    def _load_or_create_key(self) -> bytes:
        """
        Load an existing encryption key or create one.

        Returns:
            bytes: Fernet encryption key.
        """
        if self.key_file.exists():
            return self._load_key()

        return self._generate_key()

    def _generate_key(self) -> bytes:
        """
        Generate and securely store a new encryption key.

        Returns:
            bytes: Generated key.
        """
        key = Fernet.generate_key()

        with self.key_file.open("wb") as file:
            file.write(key)

        return key

    def _load_key(self) -> bytes:
        """
        Load encryption key from disk.

        Returns:
            bytes: Loaded key.

        Raises:
            ValueError: If key is invalid.
        """
        try:
            with self.key_file.open("rb") as file:
                key = file.read().strip()

            # Validate key by creating a Fernet instance.
            Fernet(key)

            return key

        except Exception as exc:
            raise ValueError(
                "Encryption key file is corrupted."
            ) from exc

    # ------------------------------------------------------------------
    # Encryption Operations
    # ------------------------------------------------------------------

    def encrypt(self, value: str) -> str:
        """
        Encrypt a string.

        Args:
            value: Plain text.

        Returns:
            str: Base64 encoded encrypted value.
        """
        if not isinstance(value, str):
            raise TypeError("Value must be a string.")

        encrypted = self.fernet.encrypt(
            value.encode("utf-8")
        )

        return encrypted.decode("utf-8")

    def decrypt(self, encrypted_value: str) -> str:
        """
        Decrypt an encrypted string.

        Args:
            encrypted_value: Encrypted text.

        Returns:
            str: Plain text.

        Raises:
            ValueError: If data cannot be decrypted.
        """
        try:
            decrypted = self.fernet.decrypt(
                encrypted_value.encode("utf-8")
            )

            return decrypted.decode("utf-8")

        except InvalidToken as exc:
            raise ValueError(
                "Encrypted data is corrupted or invalid."
            ) from exc

        except Exception as exc:
            raise ValueError(
                "Failed to decrypt data."
            ) from exc

    # ------------------------------------------------------------------
    # Bulk Encryption Helpers
    # ------------------------------------------------------------------

    def encrypt_fields(
        self,
        username: str,
        password: str,
        notes: str
    ) -> dict[str, str]:
        """
        Encrypt credential fields.

        Returns:
            dict[str, str]
        """
        return {
            "username": self.encrypt(username),
            "password": self.encrypt(password),
            "notes": self.encrypt(notes)
        }

    def decrypt_fields(
        self,
        username: str,
        password: str,
        notes: str
    ) -> dict[str, str]:
        """
        Decrypt credential fields.

        Returns:
            dict[str, str]
        """
        return {
            "username": self.decrypt(username),
            "password": self.decrypt(password),
            "notes": self.decrypt(notes)
        }

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_key(self) -> bool:
        """
        Verify that the loaded key is valid.

        Returns:
            bool
        """
        try:
            Fernet(self.key)
            return True
        except Exception:
            return False

    def validate_encrypted_value(
        self,
        value: str
    ) -> bool:
        """
        Check whether a value appears to be a valid Fernet token.

        Args:
            value: Encrypted string.

        Returns:
            bool
        """
        try:
            decoded = base64.urlsafe_b64decode(
                value.encode("utf-8")
            )

            return len(decoded) > 0

        except Exception:
            return False

    # ------------------------------------------------------------------
    # Key Information
    # ------------------------------------------------------------------

    def key_exists(self) -> bool:
        """
        Determine whether the key file exists.

        Returns:
            bool
        """
        return self.key_file.exists()

    def get_key_path(self) -> Path:
        """
        Return the key file path.

        Returns:
            Path
        """
        return self.key_file