"""
main.py

Entry point for the secure Password Manager CLI application.
"""

from __future__ import annotations

from pathlib import Path
from getpass import getpass

from master_password import MasterPasswordManager
from encryption_manager import EncryptionManager
from vault_manager import VaultManager
from password_generator import PasswordGenerator


BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"


class CLI:
    """
    Command Line Interface for the Password Manager.
    """

    def __init__(self) -> None:
        self.master = MasterPasswordManager(STORAGE_DIR)
        self.encryption = EncryptionManager(STORAGE_DIR)
        self.vault = VaultManager(STORAGE_DIR, self.encryption)
        self.generator = PasswordGenerator()

        self.authenticated = False

    # ------------------------------------------------------------------
    # Authentication Flow
    # ------------------------------------------------------------------

    def run(self) -> None:
        """
        Start the application.
        """
        print("\n=== Secure Password Manager ===\n")

        if not self.master.master_password_exists():
            self.master.setup_master_password()

        self.authenticated = self.master.authenticate()

        if not self.authenticated:
            print("Access denied.")
            return

        self.main_menu()

    # ------------------------------------------------------------------
    # Main Menu
    # ------------------------------------------------------------------

    def main_menu(self) -> None:
        """
        Display main menu loop.
        """
        while True:
            if self.master.session_expired():
                print("\nSession expired. Please login again.")
                self.authenticated = self.master.authenticate()
                if not self.authenticated:
                    print("Access denied.")
                    return

            self.master.refresh_session()

            print(
                "\n=== Main Menu ===\n"
                "1. Add Credential\n"
                "2. View Credentials\n"
                "3. Search Credential\n"
                "4. Update Credential\n"
                "5. Delete Credential\n"
                "6. Generate Password\n"
                "7. Export Vault\n"
                "8. Exit\n"
            )

            choice = input("Select option: ").strip()

            match choice:
                case "1":
                    self.add_credential()
                case "2":
                    self.view_credentials()
                case "3":
                    self.search_credentials()
                case "4":
                    self.update_credential()
                case "5":
                    self.delete_credential()
                case "6":
                    self.generate_password()
                case "7":
                    self.export_vault()
                case "8":
                    print("Goodbye.")
                    break
                case _:
                    print("Invalid option.")

    # ------------------------------------------------------------------
    # Feature Actions
    # ------------------------------------------------------------------

    def add_credential(self) -> None:
        print("\n=== Add Credential ===")

        website = input("Website: ").strip()
        username = input("Username: ").strip()

        use_generator = input("Generate password? (y/n): ").lower().strip()

        if use_generator == "y":
            password = self.generate_password(return_value=True)
        else:
            password = getpass("Password: ")

        notes = input("Notes (optional): ").strip()

        try:
            cred = self.vault.add_credential(
                website=website,
                username=username,
                password=password,
                notes=notes,
            )

            print(f"Credential saved (ID: {cred.id})")

        except Exception as exc:
            print(f"Error: {exc}")

    def view_credentials(self) -> None:
        print("\n=== Stored Credentials ===")

        creds = self.vault.get_all_credentials()

        if not creds:
            print("No credentials found.")
            return

        for c in creds:
            print(
                f"\nID: {c.id}\n"
                f"Website: {c.website}\n"
                f"Username: {c.username}\n"
                f"Created: {c.created_at}\n"
                f"Updated: {c.updated_at}\n"
            )

    def search_credentials(self) -> None:
        print("\n=== Search Credentials ===")

        query = input("Search (website/username): ").strip()

        results = self.vault.search(query)

        if not results:
            print("No matches found.")
            return

        for c in results:
            print(
                f"\nID: {c.id}\n"
                f"Website: {c.website}\n"
                f"Username: {c.username}\n"
            )

    def update_credential(self) -> None:
        print("\n=== Update Credential ===")

        cred_id = input("Enter Credential ID: ").strip()

        cred = self.vault.get_credential(cred_id)

        if not cred:
            print("Credential not found.")
            return

        print("Leave blank to keep current value.")

        website = input(f"Website ({cred.website}): ").strip() or None
        username = input(f"Username ({cred.username}): ").strip() or None

        change_password = input("Change password? (y/n): ").lower().strip()

        password = None
        if change_password == "y":
            password = getpass("New Password: ")

        notes = input("Notes (optional): ").strip() or None

        success = self.vault.update_credential(
            cred_id,
            website=website,
            username=username,
            password=password,
            notes=notes,
        )

        if success:
            print("Credential updated.")
        else:
            print("Update failed.")

    def delete_credential(self) -> None:
        print("\n=== Delete Credential ===")

        cred_id = input("Enter Credential ID: ").strip()

        if not self.master.verify_for_sensitive_operation():
            print("Authentication failed.")
            return

        if self.vault.delete_credential(cred_id):
            print("Credential deleted.")
        else:
            print("Credential not found.")

    def generate_password(self, return_value: bool = False) -> str | None:
        print("\n=== Password Generator ===")

        try:
            length = int(input("Length (default 16): ") or "16")
        except ValueError:
            length = 16

        upper = input("Include uppercase? (y/n): ").lower() == "y"
        numbers = input("Include numbers? (y/n): ").lower() == "y"
        symbols = input("Include symbols? (y/n): ").lower() == "y"

        try:
            password = self.generator.generate(
                length=length,
                include_uppercase=upper,
                include_numbers=numbers,
                include_symbols=symbols,
            )

            print(f"\nGenerated Password: {password}\n")

            if return_value:
                return password

        except Exception as exc:
            print(f"Error: {exc}")

        return None

    def export_vault(self) -> None:
        print("\n=== Export Vault ===")

        if not self.master.verify_for_sensitive_operation():
            print("Authentication failed.")
            return

        path = input("Export file name (e.g., export.json): ").strip()

        if not path:
            print("Invalid file name.")
            return

        export_path = STORAGE_DIR / path

        success = self.vault.export_vault(export_path)

        if success:
            print(f"Vault exported to {export_path}")
        else:
            print("Export failed.")


# ----------------------------------------------------------------------
# Entry Point
# ----------------------------------------------------------------------

if __name__ == "__main__":
    cli = CLI()
    cli.run()