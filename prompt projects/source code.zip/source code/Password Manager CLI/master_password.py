"""
master_password.py

Handles master password creation, validation, hashing, verification,
login attempt tracking, and secure storage.
"""

from __future__ import annotations

import json
import hashlib
import secrets
from pathlib import Path
from datetime import datetime, timedelta
from getpass import getpass


class MasterPasswordManager:
    """
    Manage creation and verification of the master password.
    """

    MAX_LOGIN_ATTEMPTS = 3
    SESSION_TIMEOUT_MINUTES = 15

    def __init__(self, storage_dir: Path) -> None:
        self.storage_dir = storage_dir
        self.master_file = self.storage_dir / "master.json"
        self.session_start: datetime | None = None

    # ------------------------------------------------------------------
    # Public Methods
    # ------------------------------------------------------------------

    def master_password_exists(self) -> bool:
        """
        Check whether the master password has been initialized.
        """
        return self.master_file.exists()

    def setup_master_password(self) -> bool:
        """
        Create and store the master password.

        Returns:
            bool: True if setup succeeds.
        """
        print("\n=== Create Master Password ===")

        while True:
            password = getpass("Create master password: ")

            valid, message = self.validate_password_strength(password)

            if not valid:
                print(f"Error: {message}")
                continue

            confirm = getpass("Confirm master password: ")

            if password != confirm:
                print("Passwords do not match.\n")
                continue

            salt = secrets.token_hex(32)
            password_hash = self.hash_password(password, salt)

            data = {
                "salt": salt,
                "password_hash": password_hash,
                "created_at": datetime.utcnow().isoformat()
            }

            try:
                self.storage_dir.mkdir(parents=True, exist_ok=True)

                with self.master_file.open(
                    "w",
                    encoding="utf-8"
                ) as file:
                    json.dump(data, file, indent=4)

                print("Master password created successfully.")
                return True

            except OSError:
                print("Failed to save master password.")
                return False

    def authenticate(self) -> bool:
        """
        Authenticate user.

        Allows only three attempts.

        Returns:
            bool: Authentication result.
        """
        if not self.master_password_exists():
            return False

        attempts = 0

        while attempts < self.MAX_LOGIN_ATTEMPTS:
            password = getpass("Enter master password: ")

            if self.verify_password(password):
                self.start_session()
                return True

            attempts += 1
            remaining = self.MAX_LOGIN_ATTEMPTS - attempts

            if remaining > 0:
                print(
                    f"Incorrect password. "
                    f"{remaining} attempt(s) remaining."
                )

        print("Maximum login attempts exceeded.")
        return False

    def verify_password(self, password: str) -> bool:
        """
        Verify a password against the stored hash.

        Args:
            password: Password to verify.

        Returns:
            bool
        """
        try:
            data = self._load_master_data()

            stored_hash = data["password_hash"]
            salt = data["salt"]

            password_hash = self.hash_password(password, salt)

            return secrets.compare_digest(
                stored_hash,
                password_hash
            )

        except (KeyError, ValueError, OSError):
            return False

    def verify_for_sensitive_operation(self) -> bool:
        """
        Require password re-entry for sensitive operations.

        Returns:
            bool
        """
        password = getpass(
            "Re-enter master password: "
        )

        return self.verify_password(password)

    def session_expired(self) -> bool:
        """
        Determine whether the session has expired.

        Returns:
            bool
        """
        if self.session_start is None:
            return True

        expiration = self.session_start + timedelta(
            minutes=self.SESSION_TIMEOUT_MINUTES
        )

        return datetime.utcnow() > expiration

    def refresh_session(self) -> None:
        """
        Refresh active session timer.
        """
        self.session_start = datetime.utcnow()

    # ------------------------------------------------------------------
    # Password Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def validate_password_strength(
        password: str
    ) -> tuple[bool, str]:
        """
        Validate password strength.

        Requirements:
        - 12 characters minimum
        - Uppercase letter
        - Lowercase letter
        - Number
        - Special character

        Returns:
            tuple[bool, str]
        """
        if len(password) < 12:
            return (
                False,
                "Password must contain at least 12 characters."
            )

        has_upper = False
        has_lower = False
        has_digit = False
        has_special = False

        special_chars = (
            "!@#$%^&*()-_=+[]{};:,.<>/?\\|`~"
        )

        for char in password:
            if char.isupper():
                has_upper = True
            elif char.islower():
                has_lower = True
            elif char.isdigit():
                has_digit = True
            elif char in special_chars:
                has_special = True

        if not has_upper:
            return (
                False,
                "Password must contain an uppercase letter."
            )

        if not has_lower:
            return (
                False,
                "Password must contain a lowercase letter."
            )

        if not has_digit:
            return (
                False,
                "Password must contain a number."
            )

        if not has_special:
            return (
                False,
                "Password must contain a special character."
            )

        return True, "Password is valid."

    @staticmethod
    def hash_password(
        password: str,
        salt: str
    ) -> str:
        """
        Hash a password using PBKDF2-HMAC-SHA256.

        Args:
            password: Plain password.
            salt: Hex-encoded salt.

        Returns:
            str: Hex digest.
        """
        hashed = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            200_000
        )

        return hashed.hex()

    # ------------------------------------------------------------------
    # Internal Methods
    # ------------------------------------------------------------------

    def _load_master_data(self) -> dict:
        """
        Load master.json.

        Returns:
            dict

        Raises:
            ValueError
            OSError
        """
        with self.master_file.open(
            "r",
            encoding="utf-8"
        ) as file:
            data = json.load(file)

        if (
            "password_hash" not in data or
            "salt" not in data
        ):
            raise ValueError(
                "Corrupted master password file."
            )

        return data

    def start_session(self) -> None:
        """
        Start authenticated session.
        """
        self.session_start = datetime.utcnow()