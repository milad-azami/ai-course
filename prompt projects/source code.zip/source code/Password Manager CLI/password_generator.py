"""
password_generator.py

Generates cryptographically secure passwords using Python's secrets module.
"""

from __future__ import annotations

import secrets
import string


class PasswordGenerator:
    """
    Secure password generator using cryptographically safe randomness.
    """

    def __init__(self) -> None:
        self.lowercase = string.ascii_lowercase
        self.uppercase = string.ascii_uppercase
        self.digits = string.digits
        self.symbols = "!@#$%^&*()-_=+[]{};:,.<>/?\\|~"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        length: int = 16,
        include_uppercase: bool = True,
        include_numbers: bool = True,
        include_symbols: bool = True,
    ) -> str:
        """
        Generate a secure random password.

        Args:
            length: Password length (minimum recommended 12).
            include_uppercase: Include uppercase letters.
            include_numbers: Include digits.
            include_symbols: Include special characters.

        Returns:
            str: Generated password.

        Raises:
            ValueError: If length is too small or configuration invalid.
        """

        if length < 8:
            raise ValueError("Password length must be at least 8 characters.")

        charset = list(self.lowercase)

        required_chars = [
            secrets.choice(self.lowercase)
        ]

        if include_uppercase:
            charset.extend(self.uppercase)
            required_chars.append(secrets.choice(self.uppercase))

        if include_numbers:
            charset.extend(self.digits)
            required_chars.append(secrets.choice(self.digits))

        if include_symbols:
            charset.extend(self.symbols)
            required_chars.append(secrets.choice(self.symbols))

        if not charset:
            raise ValueError("No character sets selected for password generation.")

        # Fill remaining length
        remaining_length = length - len(required_chars)

        if remaining_length < 0:
            raise ValueError(
                "Length too small for selected complexity requirements."
            )

        password_chars = required_chars[:]

        for _ in range(remaining_length):
            password_chars.append(secrets.choice(charset))

        # Shuffle securely
        for i in range(len(password_chars) - 1, 0, -1):
            j = secrets.randbelow(i + 1)
            password_chars[i], password_chars[j] = password_chars[j], password_chars[i]

        return "".join(password_chars)

    # ------------------------------------------------------------------
    # Strength Estimation
    # ------------------------------------------------------------------

    def estimate_strength(self, password: str) -> str:
        """
        Estimate password strength.

        Returns:
            str: weak | medium | strong
        """

        score = 0

        if len(password) >= 12:
            score += 2
        elif len(password) >= 8:
            score += 1

        if any(c.islower() for c in password):
            score += 1

        if any(c.isupper() for c in password):
            score += 1

        if any(c.isdigit() for c in password):
            score += 1

        if any(c in self.symbols for c in password):
            score += 2

        if score <= 3:
            return "weak"
        elif score <= 5:
            return "medium"
        else:
            return "strong"

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def generate_bulk(self, count: int, **kwargs) -> list[str]:
        """
        Generate multiple passwords.

        Args:
            count: Number of passwords.
            kwargs: Options for generate().

        Returns:
            list[str]
        """
        return [self.generate(**kwargs) for _ in range(count)]