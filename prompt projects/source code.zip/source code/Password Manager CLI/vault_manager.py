"""
vault_manager.py

Manages encrypted credential storage, CRUD operations,
search, persistence, export, and vault integrity.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from datetime import datetime

from credential import Credential
from encryption_manager import EncryptionManager


class VaultManager:
    """
    Handles all credential operations and secure persistence.
    """

    def __init__(
        self,
        storage_dir: Path,
        encryption_manager: EncryptionManager,
    ) -> None:
        self.storage_dir = storage_dir
        self.vault_file = self.storage_dir / "vault.json"
        self.encryption = encryption_manager

        self.storage_dir.mkdir(parents=True, exist_ok=True)

        self.credentials: dict[str, Credential] = {}
        self.load_vault()

    # ------------------------------------------------------------------
    # Load / Save
    # ------------------------------------------------------------------

    def load_vault(self) -> None:
        """
        Load vault from disk and decrypt credentials.
        """
        if not self.vault_file.exists():
            self.credentials = {}
            return

        try:
            with self.vault_file.open("r", encoding="utf-8") as f:
                data = json.load(f)

            if not isinstance(data, list):
                raise ValueError("Corrupted vault format.")

            self.credentials = {}

            for item in data:
                decrypted = {
                    "id": item["id"],
                    "website": item["website"],
                    "username": self.encryption.decrypt(item["username"]),
                    "password": self.encryption.decrypt(item["password"]),
                    "notes": self.encryption.decrypt(item["notes"]),
                    "created_at": item["created_at"],
                    "updated_at": item["updated_at"],
                }

                credential = Credential.from_dict(decrypted)
                self.credentials[credential.id] = credential

        except (json.JSONDecodeError, KeyError, ValueError):
            print("Warning: Vault file is corrupted or unreadable.")
            self.credentials = {}

    def save_vault(self) -> None:
        """
        Encrypt and persist vault to disk.
        """
        try:
            data = []

            for cred in self.credentials.values():
                encrypted = {
                    "id": cred.id,
                    "website": cred.website,
                    "username": self.encryption.encrypt(cred.username),
                    "password": self.encryption.encrypt(cred.password),
                    "notes": self.encryption.encrypt(cred.notes),
                    "created_at": cred.created_at,
                    "updated_at": cred.updated_at,
                }
                data.append(encrypted)

            temp_file = self.vault_file.with_suffix(".tmp")

            with temp_file.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)

            temp_file.replace(self.vault_file)

        except Exception as exc:
            print(f"Error saving vault: {exc}")

    # ------------------------------------------------------------------
    # CRUD Operations
    # ------------------------------------------------------------------

    def add_credential(
        self,
        website: str,
        username: str,
        password: str,
        notes: str = "",
    ) -> Credential:
        """
        Add a new credential.
        """
        credential_id = str(uuid.uuid4())

        credential = Credential(
            credential_id=credential_id,
            website=website,
            username=username,
            password=password,
            notes=notes,
        )

        credential.validate()

        self.credentials[credential.id] = credential
        self.save_vault()

        return credential

    def update_credential(
        self,
        credential_id: str,
        website: str | None = None,
        username: str | None = None,
        password: str | None = None,
        notes: str | None = None,
    ) -> bool:
        """
        Update an existing credential.
        """
        cred = self.credentials.get(credential_id)

        if not cred:
            return False

        cred.update(
            website=website,
            username=username,
            password=password,
            notes=notes,
        )

        self.save_vault()
        return True

    def delete_credential(self, credential_id: str) -> bool:
        """
        Delete a credential.
        """
        if credential_id in self.credentials:
            del self.credentials[credential_id]
            self.save_vault()
            return True

        return False

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def get_all_credentials(self) -> list[Credential]:
        """
        Return all credentials.
        """
        return list(self.credentials.values())

    def get_credential(self, credential_id: str) -> Credential | None:
        """
        Get a credential by ID.
        """
        return self.credentials.get(credential_id)

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str) -> list[Credential]:
        """
        Search credentials by website or username (case-insensitive).
        """
        query = query.lower().strip()

        results = []

        for cred in self.credentials.values():
            if (
                query in cred.website.lower()
                or query in cred.username.lower()
            ):
                results.append(cred)

        return results

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_vault(self, export_path: Path) -> bool:
        """
        Export decrypted vault to JSON (requires master verification externally).
        """
        try:
            data = [
                cred.to_dict() for cred in self.credentials.values()
            ]

            with export_path.open("w", encoding="utf-8") as f:
                json.dump(
                    {
                        "exported_at": datetime.utcnow().isoformat(),
                        "credentials": data,
                    },
                    f,
                    indent=4,
                )

            return True

        except Exception as exc:
            print(f"Export failed: {exc}")
            return False

    # ------------------------------------------------------------------
    # Integrity
    # ------------------------------------------------------------------

    def is_empty(self) -> bool:
        """
        Check if vault has no credentials.
        """
        return len(self.credentials) == 0

    def count(self) -> int:
        """
        Return number of stored credentials.
        """
        return len(self.credentials)

    # ------------------------------------------------------------------
    # Debug / Safe View
    # ------------------------------------------------------------------

    def list_safe(self) -> list[dict]:
        """
        Return non-sensitive view of vault.
        """
        return [c.to_safe_dict() for c in self.credentials.values()]