// ================= STORAGE LAYER =================
const Storage = (function () {
  const KEY = "kanban_tasks";

  function load() {
    const data = localStorage.getItem(KEY);
    return data ? JSON.parse(data) : [];
  }

  function save(tasks) {
    localStorage.setItem(KEY, JSON.stringify(tasks));
  }

  return { load, save };
})();

// ================= STATE MANAGEMENT =================
const State = (function () {
  let tasks = Storage.load();
  let listeners = [];

  function notify() {
    Storage.save(tasks);
    listeners.forEach((l) => l(tasks));
  }

  function subscribe(fn) {
    listeners.push(fn);
  }

  function addTask(title, description) {
    tasks.push({
      id: crypto.randomUUID(),
      title,
      description,
      status: "todo",
      createdAt: Date.now(),
    });
    notify();
  }

  function updateTask(id, updates) {
    tasks = tasks.map((t) => (t.id === id ? { ...t, ...updates } : t));
    notify();
  }

  function deleteTask(id) {
    tasks = tasks.filter((t) => t.id !== id);
    notify();
  }

  function getTasks() {
    return tasks;
  }

  return {
    subscribe,
    addTask,
    updateTask,
    deleteTask,
    getTasks,
  };
})();

// ================= UI LAYER =================
const UI = (function () {
  const modal = document.getElementById("taskModal");
  const titleInput = document.getElementById("taskTitle");
  const descInput = document.getElementById("taskDesc");
  const saveBtn = document.getElementById("saveTaskBtn");
  const cancelBtn = document.getElementById("cancelTaskBtn");
  const addBtn = document.getElementById("addTaskBtn");

  let editId = null;

  function openModal(task = null) {
    modal.style.display = "flex";
    if (task) {
      titleInput.value = task.title;
      descInput.value = task.description;
      editId = task.id;
    } else {
      titleInput.value = "";
      descInput.value = "";
      editId = null;
    }
  }

  function closeModal() {
    modal.style.display = "none";
  }

  function render(tasks) {
    ["todo", "inprogress", "done"].forEach((status) => {
      const list = document.getElementById(status);
      list.innerHTML = "";

      const filtered = tasks.filter((t) => t.status === status);

      document.getElementById(`count-${status}`).textContent =
        filtered.length;

      if (filtered.length === 0) {
        list.innerHTML = `<p class="empty">No tasks</p>`;
      }

      filtered.forEach((task) => {
        const el = document.createElement("div");
        el.className = "task";
        el.draggable = true;
        el.dataset.id = task.id;

        el.innerHTML = `
          <div class="task-title">${task.title}</div>
          <div class="task-desc">${task.description || ""}</div>
          <div class="task-actions">
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
          </div>
        `;

        // Drag events
        el.addEventListener("dragstart", (e) => {
          e.dataTransfer.setData("text/plain", task.id);
        });

        // Actions
        el.querySelector(".delete").onclick = () => {
          if (confirm("Delete this task?")) {
            State.deleteTask(task.id);
          }
        };

        el.querySelector(".edit").onclick = () => openModal(task);

        list.appendChild(el);
      });
    });
  }

  function initDragAndDrop() {
    document.querySelectorAll(".task-list").forEach((list) => {
      list.addEventListener("dragover", (e) => {
        e.preventDefault();
        list.classList.add("drag-over");
      });

      list.addEventListener("dragleave", () => {
        list.classList.remove("drag-over");
      });

      list.addEventListener("drop", (e) => {
        e.preventDefault();
        list.classList.remove("drag-over");

        const id = e.dataTransfer.getData("text/plain");
        const status = list.id;

        State.updateTask(id, { status });
      });
    });
  }

  function bindEvents() {
    addBtn.onclick = () => openModal();

    cancelBtn.onclick = closeModal;

    saveBtn.onclick = () => {
      const title = titleInput.value.trim();
      const description = descInput.value.trim();

      if (!title) return;

      if (editId) {
        State.updateTask(editId, { title, description });
      } else {
        State.addTask(title, description);
      }

      closeModal();
    };

    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });
  }

  return {
    init: function () {
      State.subscribe(render);
      bindEvents();
      initDragAndDrop();
      render(State.getTasks());
    },
  };
})();

// ================= INIT APP =================
document.addEventListener("DOMContentLoaded", () => {
  UI.init();
});